<h3 align="center">Cadastro de Séries em .NET :movie_camera:</h3>

<hr />

<details>
    <summary><strong>Métodos</strong></summary>
        <br />
        <ol>
            <li>Listar séries</li>
            <li>Inserir série</li>
            <li>Atualizar série</li>
            <li>Excluir série</li>
            <li>Visualizar série</li>
        </ol>
</details>

<hr />

<details>
  <summary><strong>Fonte</strong></summary>
    <br />
    <p align="left">
        Plataforma: <a href="https://web.digitalinnovation.one/home">Digital Innovation One.</a>
        <br /> 
        Desafio: <a href="https://web.digitalinnovation.one/lab/criando-um-app-de-cadastro-em-memoria-implementando-crud-de-series-em-net/learning/9432e625-663e-481a-971b-c77a4aa96d16">Criando um APP simples de cadastro de séries em .NET.</a>
    </p>
</details>

<hr />
